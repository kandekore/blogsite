// const { response } = require("express");

const newPostHandler = async (event) => {
  event.preventDefault();
  console.log("test");
  // const user = document.querySelector("#userid").value.trim();
  const title = document.querySelector("#ptinput").value.trim();
  const content = document.querySelector("#pstcnt").value.trim();

  if (title && content) {
    const response = await fetch(`/api/posts`, {
      method: "POST",
      body: JSON.stringify({ title, content }),
      headers: {
        "Content-Type": "application/json",
      },
    });

    console.log(response);

    if (response.ok) {
      //   res.status(200).json(response);
      window.location.href = "/";
    } else {
      alert("Failed to create booking");
    }
  }
};

// router.post("/api/posts", async (req, res) => {
//   console.info(`${req.method} request received to add a post`);
// let response;
// if (req.body.user && req.body.postTitle && req.body.postContent) {
//   response = {
//     status: "success",
//     data: req.body,
//   };
//   res.json(`Review for ${response.data.product} has been added!`);
// } else {
//   res.json("Request body must at least contain a product name");
// }

// Log the response body to the console
//   console.log(req.body);
// });
/*
  
           { "title": "post route",
            "content": "adding a post is easy",
  
            "user_id": 1,
            "cat_id": 1,}
            */
// try {
//   const newPost = await Post.create(req.body);
//   res.status(200).json(newPost);
// } catch (err) {
//   res.status(400).json(err);
// }

document
  .querySelector(".submitpost")
  .addEventListener("submit", newPostHandler);
